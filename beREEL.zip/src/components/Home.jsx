import React from 'react';

function Home(props) {
  return (
    <div>
      <p>Welcome to the BeREEL home page</p>
    </div>
  );
}

export default Home;
